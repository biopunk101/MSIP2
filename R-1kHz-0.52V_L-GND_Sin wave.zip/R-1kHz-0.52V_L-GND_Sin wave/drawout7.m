function drawout7(name)

file = [name '.txt']; 
out = [name '_R.txt'];
a = textread(file,'%s'); 
n = length(a(:));

if(n>=24000)
  n = 24000;
endif 

j = 1;
k = 1;
s = 1/48000;

fid = fopen(out,'wt');

for i=8:+8:n
  C1 = a(i-7);
  C2 = a(i-6);
  C3 = a(i-5);
  C4 = a(i-4);
  
  L(j) = strcat(C1, C2, C3, C4);
  L(j) = bitshift(hex2dec(L(j)), 1); #should be 1 
  
  B1 = a(i-3);
  B2 = a(i-2);
  B3 = a(i-1);
  B4 = a(i);
  
  R(j) = strcat(B1, B2, B3, B4);
  R(j) = bitshift(hex2dec(R(j)), 1);
  
  x(j) = bitcmp(cell2mat(L(j)), 24);
  y(j) = bitcmp(cell2mat(R(j)), 24);
  
  strtmp = dec2hex(x(j));
  fprintf(fid,'%s\n', strtmp); 
  strtmp = dec2hex(y(j));
  fprintf(fid,'%s\n', strtmp);       
 
  tmp = x(j)*(3300/16777214)-1650;
  if(tmp < 0)
    z(j) = tmp + 1650;
  else   
    z(j) = tmp - 1650;
  endif 
  
 
  t(j) = s * j;
  j = j + 1;

end 

fclose(fid); 


##ff = fft(t, x);
##
##figure
##plot(abs(ff));

figure
subplot(211);
plot(x);
subplot(212)
plot(y);

figure
plot(z);

##subplot(313)
##plot(z);

##xlim([1 n/2]);
##ylim([0 4096]);

max = max(x);
min = min(x);
mean = range(x);

desc = ['drawout7->' name ': ' 'max=' num2str(max), ' min=' num2str(min), ' range=' num2str(mean) ];
title(desc);
saveas(gcf, name, "png");


  